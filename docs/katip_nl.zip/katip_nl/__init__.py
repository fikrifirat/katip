"""Katip NL recognizers, browser bundle (built by src/build_nl.py)."""
